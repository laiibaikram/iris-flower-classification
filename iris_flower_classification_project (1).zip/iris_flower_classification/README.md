# Iris Flower Classification Using Machine Learning

**DecodeLabs | Artificial Intelligence Project 2 | Batch 2026**

A beginner-friendly supervised machine learning project that predicts the species of an Iris flower from four measurements using the **K-Nearest Neighbors (KNN)** classification algorithm.

## Project objective

Build, train, test, and evaluate a basic classification model using a small, well-known dataset. The project follows the workflow described in the DecodeLabs Project 2 brief.

## Dataset

This project uses the Iris dataset included with Scikit-learn, so no separate dataset download is required.

| Dataset detail | Value |
|---|---:|
| Total samples | 150 |
| Input features | 4 |
| Classes | 3 |
| Features | Sepal length, sepal width, petal length, petal width |
| Species | Setosa, Versicolor, Virginica |

All measurements are in centimetres.

## Machine learning workflow

1. **Load and explore:** Load the Iris dataset and inspect its features and class distribution.
2. **Train-test split:** Divide the data into 80% training data and 20% testing data. Stratification keeps the class proportions consistent.
3. **Feature scaling:** Apply `StandardScaler`. The scaler is fitted on training data only, then applied to the test data to avoid data leakage.
4. **Model training:** Train a K-Nearest Neighbors classifier with `k=5`.
5. **Prediction:** Predict flower species for the unseen test records.
6. **Evaluation:** Measure accuracy, weighted precision, weighted recall, weighted F1-score, and inspect the confusion matrix.

## Project structure

```text
iris_flower_classification/
│
├── main.py
├── requirements.txt
├── README.md
├── .gitignore
└── outputs/
    ├── class_distribution.png
    └── confusion_matrix.png
```

The `outputs/` charts are generated when you run the program.

## Installation and setup

### 1. Clone the repository

```bash
git clone https://github.com/YOUR-USERNAME/iris-flower-classification.git
cd iris-flower-classification
```

### 2. Create a virtual environment (recommended)

```bash
python -m venv .venv
```

Activate it:

**Windows**
```bash
.venv\Scripts\activate
```

**macOS / Linux**
```bash
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the project

```bash
python main.py
```

The program prints the dataset overview, train/test sizes, evaluation metrics, classification report, confusion matrix, and a sample prediction. It also saves charts in the `outputs/` folder.

## Evaluation metrics

- **Accuracy:** Overall proportion of correct predictions.
- **Precision:** Of the predictions made for a class, how many were correct.
- **Recall:** Of the actual examples in a class, how many were found.
- **F1-score:** Harmonic mean of precision and recall.
- **Confusion matrix:** Shows correct and incorrect predictions for each class.

Weighted averages are used for precision, recall, and F1-score.

## Example prediction

The program tests a flower with these measurements:

`[5.1, 3.5, 1.4, 0.2]`

The model predicts its Iris species from the learned patterns.

## Important notes

- This is a learning and portfolio project, not a production botanical identification system.
- The Iris dataset is small and balanced, so its results should not be generalized to every flower dataset.
- Results depend on the train/test split and model settings.
- The random seed is fixed (`random_state=42`) to make the split reproducible.

## Skills demonstrated

`Python` · `Pandas` · `Scikit-learn` · `Supervised Learning` · `KNN` · `Feature Scaling` · `Train-Test Split` · `Model Evaluation` · `Data Visualization`

---

**Created as DecodeLabs Artificial Intelligence Project 2.**
