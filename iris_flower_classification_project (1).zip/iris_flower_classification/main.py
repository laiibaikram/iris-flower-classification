"""
Iris Flower Classification
DecodeLabs - Artificial Intelligence Project 2

A supervised machine learning project that classifies Iris flowers
using a K-Nearest Neighbors (KNN) model.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler


OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


def load_and_explore_data():
    """Load the built-in Iris dataset and display a quick overview."""
    iris = load_iris(as_frame=True)
    X = iris.data
    y = iris.target
    target_names = iris.target_names

    print("\n" + "=" * 62)
    print("IRIS FLOWER CLASSIFICATION - DATA OVERVIEW")
    print("=" * 62)
    print(f"Number of samples : {len(X)}")
    print(f"Number of features: {X.shape[1]}")
    print(f"Flower classes    : {', '.join(target_names)}")
    print("\nFirst five records:")
    print(X.head())
    print("\nClass distribution:")
    print(y.map(dict(enumerate(target_names))).value_counts())

    return X, y, target_names


def split_and_scale_data(X, y):
    """Split data first, then fit the scaler only on training data."""
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42,
        stratify=y,
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    print("\nDATA SPLIT")
    print(f"Training samples: {len(X_train)} (80%)")
    print(f"Testing samples : {len(X_test)} (20%)")

    return X_train_scaled, X_test_scaled, y_train, y_test, scaler


def train_model(X_train, y_train, k=5):
    """Train a KNN classifier."""
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train, y_train)
    print(f"\nModel trained successfully using KNN (k={k}).")
    return model


def evaluate_model(model, X_test, y_test, target_names):
    """Evaluate the model using multiple classification metrics."""
    predictions = model.predict(X_test)

    accuracy = accuracy_score(y_test, predictions)
    precision = precision_score(y_test, predictions, average="weighted", zero_division=0)
    recall = recall_score(y_test, predictions, average="weighted", zero_division=0)
    f1 = f1_score(y_test, predictions, average="weighted", zero_division=0)
    matrix = confusion_matrix(y_test, predictions)

    print("\n" + "=" * 62)
    print("MODEL EVALUATION")
    print("=" * 62)
    print(f"Accuracy : {accuracy:.2%}")
    print(f"Precision: {precision:.2%}")
    print(f"Recall   : {recall:.2%}")
    print(f"F1-score : {f1:.2%}")

    print("\nClassification Report:")
    print(classification_report(y_test, predictions, target_names=target_names))

    print("Confusion Matrix:")
    print(matrix)

    return predictions, matrix, {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1_score": f1,
    }


def save_visualizations(y, predictions, matrix, target_names):
    """Save class distribution and confusion matrix charts."""
    labels = pd.Series(y).map(dict(enumerate(target_names)))

    plt.figure(figsize=(8, 5))
    sns.countplot(x=labels, hue=labels, palette="Set2", legend=False)
    plt.title("Iris Dataset - Class Distribution")
    plt.xlabel("Flower Species")
    plt.ylabel("Number of Samples")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "class_distribution.png", dpi=150)
    plt.close()

    plt.figure(figsize=(7, 5))
    sns.heatmap(
        matrix,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=target_names,
        yticklabels=target_names,
    )
    plt.title("KNN Classification - Confusion Matrix")
    plt.xlabel("Predicted Label")
    plt.ylabel("Actual Label")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "confusion_matrix.png", dpi=150)
    plt.close()

    print(f"\nCharts saved in: {OUTPUT_DIR.resolve()}")


def predict_new_flower(model, scaler, target_names):
    """Demonstrate prediction for a new flower measurement."""
    # Example measurements in cm:
    # sepal length, sepal width, petal length, petal width
    sample = pd.DataFrame(
        [[5.1, 3.5, 1.4, 0.2]],
        columns=["sepal length (cm)", "sepal width (cm)",
                 "petal length (cm)", "petal width (cm)"],
    )
    sample_scaled = scaler.transform(sample)
    predicted_class = model.predict(sample_scaled)[0]

    print("\nNEW FLOWER PREDICTION")
    print("Measurements (cm): [5.1, 3.5, 1.4, 0.2]")
    print(f"Predicted species : {target_names[predicted_class]}")


def main():
    X, y, target_names = load_and_explore_data()
    X_train, X_test, y_train, y_test, scaler = split_and_scale_data(X, y)
    model = train_model(X_train, y_train, k=5)
    predictions, matrix, _ = evaluate_model(
        model, X_test, y_test, target_names
    )
    save_visualizations(y, predictions, matrix, target_names)
    predict_new_flower(model, scaler, target_names)

    print("\nProject completed successfully!")


if __name__ == "__main__":
    main()
